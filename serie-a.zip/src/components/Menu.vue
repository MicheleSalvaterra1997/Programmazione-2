
<template>
  <v-app id="inspire" white>
    <v-navigation-drawer v-model="drawer" clipped fixed app>
      <v-list dense>
        <v-list-tile to="/classifica">
          <v-list-tile-action>
            <v-icon>view_list</v-icon>
          </v-list-tile-action>

          <v-list-tile-content>
            <v-list-tile-title>CLASSIFICA</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>

        <v-list-tile to="/marcatori">
          <v-list-tile-action>
            <v-icon>sports_soccer</v-icon>
          </v-list-tile-action>

          <v-list-tile-content>
            <v-list-tile-title>MARCATORI</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>

        <v-list-tile to="/squadre">
          <v-list-tile-action>
            <v-icon>group_work</v-icon>
          </v-list-tile-action>

          <v-list-tile-content>
            <v-list-tile-title>SQUADRE</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>

        <v-list-tile to="/partite">
          <v-list-tile-action>
            <v-icon>today</v-icon>
          </v-list-tile-action>

          <v-list-tile-content>
            <v-list-tile-title>PARTITE</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>

        <!--<v-list-tile to="/giocatori">
          <v-list-tile-action>
            <v-icon>group</v-icon>
          </v-list-tile-action>

          <v-list-tile-content>
            <v-list-tile-title>GIOCATORI</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>-->
      </v-list>
    </v-navigation-drawer>
    <v-toolbar app fixed clipped-left color="blue darken-3" dark>
      <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
      <v-toolbar-title>SERIE A</v-toolbar-title>
    </v-toolbar>
    <v-content>
      <v-container>
        <keep-alive>
          <router-view />
        </keep-alive>
      </v-container>
    </v-content>
    <v-footer app fixed>
      <v-flex text-xs-center xs12>&copy;Michele Patricio</v-flex>
    </v-footer>
  </v-app>
</template>

<script>
export default {
  data: () => ({
    drawer: true,
  }),
  props: {
    source: String,
  },
};
</script>
