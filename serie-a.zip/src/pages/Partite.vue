
<template>
  <div id="inspire">
    <v-app id="inspire">
      <div class="partite-contain">
        <div class="partite" v-for="match of matches" :key="match.id">
          <table class="partite-table">
            <tr>
              <td class="partite-td1">
                <div class="logo">
                  <img :src="match.homeTeam.logo" class="partite-img-small" />
                </div>
              </td>
              <td class="partite-td2">
                <p class="partite-squadra">{{ match.homeTeam.team_name }}</p>
              </td>
              <td class="partite-td3">
                <p class="risultato" v-if="match.goalsHomeTeam != null">
                  {{ match.goalsHomeTeam }}
                </p>
                <p class="risultato" v-else>
                  {{ match.event_date.substring(0, 10) }}
                </p>
              </td>
            </tr>
            <tr>
              <td class="partite-td1">
                <div class="logo">
                  <img :src="match.awayTeam.logo" class="partite-img-small" />
                </div>
              </td>
              <td class="partite-td2">
                <p class="partite-squadra">{{ match.awayTeam.team_name }}</p>
              </td>
              <td class="partite-td3">
                <p class="risultato" v-if="match.goalsAwayTeam != null">
                  {{ match.goalsAwayTeam }}
                </p>
                <p class="risultato" v-else>
                  {{ match.event_date.substring(11, 16) }}
                </p>
                <!--{{ response.create_at | formatDate }}-->
              </td>
            </tr>
          </table>
        </div>
      </div>
    </v-app>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "app",
  data() {
    return {
      matches: undefined,
    };
  },

  async created() {
    try {
      var currentRound = "";
      
      axios({
        method: "GET",
        url:
          "https://api-football-v1.p.rapidapi.com/v2/fixtures/rounds/2857/current",
        headers: {
          "content-type": "application/octet-stream",
          "x-rapidapi-host": "api-football-v1.p.rapidapi.com",
          "x-rapidapi-key":
            "ff39fe02a2msh3e312b130495454p1dc972jsn1d36fba9b267",
          useQueryString: true,
        },
      })
        .then((response) => {
          console.log(response);
          currentRound = response.data.api.fixtures[0];
          console.log(currentRound);
          //this.squadre = response.data.api.standings[0];
          //console.log(this.classifica[0].teamName);
          //console.log(response.data.api.standings[0][0].teamName);
          axios({
            method: "GET",
            url:
              "https://api-football-v1.p.rapidapi.com/v2/fixtures/league/2857/" +
              currentRound,
            headers: {
              "content-type": "application/octet-stream",
              "x-rapidapi-host": "api-football-v1.p.rapidapi.com",
              "x-rapidapi-key":
                "ff39fe02a2msh3e312b130495454p1dc972jsn1d36fba9b267",
              useQueryString: true,
            },
          })
            .then((response) => {
              console.log(response);
              this.matches = response.data.api.fixtures;

              //this.squadre = response.data.api.standings[0];
              //console.log(this.classifica[0].teamName);
              //console.log(response.data.api.standings[0][0].teamName);
            })
            .catch((error) => {
              console.log(error);
            });
        })
        .catch((error) => {
          console.log(error);
        });
    } catch (e) {
      console.error(e);
    }
  },
};
</script>

<style>
.partite-td1 {
  width: 10%;
}
.partite-td2 {
  width: 55%;
}
.partite-td3 {
  width: 35%;
}
.partite-table {
  width: 100%;
}
.partite-table td {
  max-height: 100px;
  vertical-align: middle;
}
.partite-img-small {
  width: 30px;
  height: 30px;
  display: block;
  margin-left: 10px;
}

.partite-contain {
  font-size: 0;
}
.partite {
  display: inline-block;
  margin: 8px;
  width: 350px;
  max-height: 100px;
  background-color: #ffffff;
  border-radius: 2px;
  box-shadow: 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.partite .logo {
  position: relative;
  /*height: 160px;*/
  color: #ffffff;
  /*padding-top: 40px;*/
}

.partite-squadra {
  padding-top: 10px;
  padding-left: 5px;
  font-size: 20px;
  text-align: left;
}
.risultato {
  padding-top: 10px;
  padding-left: 5px;
  padding-right: 10px;
  font-size: 16px;
  text-align: right;
}

.mdl-data-table {
  table-layout: fixed;
  width: 100%;
}
</style>
