<template>
  <div id="inspire">
    <v-app id="inspire">
      <div class="cards-set">
        <div class="card" v-for="squadra of squadre" :key="squadra.id">
          <div class="heading"><img :src="squadra.logo" /></div>
          <div class="content">
            <p class="squadra">{{ squadra.teamName }}</p>
            <button
              class="btn btn-sm btn-primary"
              v-on:click="setSquadraPreferita"
            >
              <i v-if="!is_fav" class="material-icons icon">favorite_border</i>
              <i v-else class="material-icons icon">favorite</i>
            </button>
          </div>
        </div>
      </div>
    </v-app>
  </div>
</template>

<script>
import axios from "axios";
import db from "@/firebase";
export default {
  props: ["is_fav"],
  name: "app",
  data() {
    return {
      squadre: undefined,
      squadra: "100",
    };
  },
  methods: {
    togglefav: function () {
      this.$emit("togglefav", !this.is_fav);
    },
    setSquadraPreferita() {
      this.$emit("togglefav", !this.is_fav);
      const squadraPref = {
        squadra: this.squadra,
      };
      db.collection("squadre")
        .add(squadraPref)
        .then(() => console.log("add to db"));
    },
  },

  async created() {
    try {
      axios({
        method: "GET",
        url: "https://api-football-v1.p.rapidapi.com/v2/leagueTable/2857",
        headers: {
          "content-type": "application/octet-stream",
          "x-rapidapi-host": "api-football-v1.p.rapidapi.com",
          "x-rapidapi-key":
            "ff39fe02a2msh3e312b130495454p1dc972jsn1d36fba9b267",
          useQueryString: true,
        },
      })
        .then((response) => {
          console.log(response);
          this.squadre = response.data.api.standings[0];
          //console.log(this.classifica[0].teamName);
          //console.log(response.data.api.standings[0][0].teamName);
        })
        .catch((error) => {
          console.log(error);
        });
    } catch (e) {
      console.error(e);
    }
  },
};
</script>

<style>
.icon {
  width: 50px;
  height: 50px;
}

h1 {
  margin: 0;
  padding: 0;
}

.squadra p {
  margin: 0.8em 0 0 0;
  padding: 0;
}
.cards-set {
  font-size: 0;
}
.card {
  display: inline-block;
  margin: 8px;
  width: 380px;
  min-height: 280px;
  font-size: 20px;
  background-color: #ffffff;
  border-radius: 20px;
  box-shadow: 0 12px 15px 0 rgba(0, 0, 0, 0.24);
}
.card .heading {
  position: relative;
  height: 160px;
  color: #ffffff;
  padding-top: 40px;
}
.card .heading h1 {
  position: absolute;
  bottom: 16px;
  left: 16px;
  font-size: 24px;
}
.card .content {
  padding: 16px;
}
.squadra {
  padding-top: 20px;
  font-size: 20px;
}

.mdl-data-table {
  table-layout: fixed;
  width: 100%;
}
</style>