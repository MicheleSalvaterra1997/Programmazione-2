<template>
  <div id="inspire">
    <v-app id="inspire">
      <table id="my-table" class="mdl-data-table mdl-js-data-table">
        <thead>
          <tr class="mdl-color--purple-700">
            <th class="mdl-data-table__cell--non-numeric mdl-color-text--white">
              SQUADRA
            </th>
            <th class="mdl-color-text--white">PG</th>
            <th class="mdl-color-text--white">V</th>
            <th class="mdl-color-text--white">P</th>
            <th class="mdl-color-text--white">S</th>
            <th class="mdl-color-text--white">PT</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="elemento of classifica" :key="elemento.id">
            <!--<td class="mdl-data-table__cell--non-numeric">
              {{ elemento.teamName }}
            </td>-->
            <td>
              <div class="logo">
                <img :src="elemento.logo" class="img-small" />
              </div>
            </td>
            <td>{{ elemento.all.matchsPlayed }}</td>
            <td>{{ elemento.all.win }}</td>
            <td>{{ elemento.all.draw }}</td>
            <td>{{ elemento.all.lose }}</td>
            <td>{{ elemento.points }}</td>
          </tr>
        </tbody>
      </table>
    </v-app>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "app",
  data() {
    return {
      classifica: undefined,
    };
  },

  async created() {
    try {
      //const res = await axios.get(`http://localhost:3000/todos`)
      //this.todos = res.data;
      // const axios = require("axios");

      axios({
        method: "GET",
        url: "https://api-football-v1.p.rapidapi.com/v2/leagueTable/2857",
        headers: {
          "content-type": "application/octet-stream",
          "x-rapidapi-host": "api-football-v1.p.rapidapi.com",
          "x-rapidapi-key":
            "ff39fe02a2msh3e312b130495454p1dc972jsn1d36fba9b267",
          useQueryString: true,
        },
      })
        .then((response) => {
          console.log(response);
          this.classifica = response.data.api.standings[0];
          //console.log(this.classifica[0].teamName);
          //console.log(response.data.api.standings[0][0].teamName);
        })
        .catch((error) => {
          console.log(error);
        });
    } catch (e) {
      console.error(e);
    }
  },
};
</script>
<style lang="stylus">
.logo {
}

.img-small {
  width: 30px;
  height: 30px;
  display: block;
}

.mdl-data-table {
  table-layout: fixed;
  width: 100%;
}

#my-table td, th {
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  -o-text-overflow: ellipsis;
}
</style>