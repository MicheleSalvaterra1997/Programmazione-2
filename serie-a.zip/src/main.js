// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from "vue";
import App from "./App";
import Vuetify from "vuetify";
import router from "./routers";
import moment from "moment";
/*import firebase from "./firebase";*/

Vue.use(Vuetify);

/* eslint-disable no-new */
new Vue({
  el: "#app",
  router,
  components: { App },
  template: "<App/>"
});

/*
let app;
firebase.onAuthStateChanged(() => {
  if (!app) {
    app = new Vue({
      router,
      render: (h) => h(App),
      components: { App },
      template: "<App/>"
    }).$mount("#app");
  }
});*/

Vue.filter("formatDate", function (value) {
  if (value) {
    return moment(String(value)).format("MM/DD/YYYY hh:mm");
  }
});

Vue.filter("formatHour", function (value) {
  if (value) {
    return moment(String(value)).format("hh:mm");
  }
});
