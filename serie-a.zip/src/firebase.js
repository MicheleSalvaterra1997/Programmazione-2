import firebase from "firebase/app";
import "firebase/auth";
import "firebase/firestore";

// firebase init - add your own config here
const firebaseConfig = {
  apiKey: "AIzaSyCQB6zXQBH9nbnZaWYc0klFlF7_DG7a7KI",
  authDomain: "my-seriea.firebaseapp.com",
  databaseURL:
    "https://my-seriea-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "my-seriea",
  storageBucket: "my-seriea.appspot.com",
  messagingSenderId: "216189565442",
  appId: "1:216189565442:web:c8299b3eee1863154f051b",
  measurementId: "G-HL3RG1XX0E"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// non fa uscire warnng in console
db.settings({ timestampsInSnapshots: true });

export { db };
