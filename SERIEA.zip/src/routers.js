import Vue from "vue";
import VueRouter from "vue-router";
import Classifica from "./pages/Classifica.vue";
import Marcatori from "./pages/Marcatori.vue";
import Squadre from "./pages/Squadre.vue";
Vue.use(VueRouter);

const routers = [
  {
    path: "/classifica",
    component: Classifica
  },
  {
    path: "/marcatori",
    component: Marcatori
  },
  {
    path: "/squadre",
    component: Squadre
  }
];

export default new VueRouter({
  mode: "hash", // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: routers
});
