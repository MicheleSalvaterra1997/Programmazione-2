<template>
  <div id="inspire">
    <v-app id="inspire">
      <table class="mdl-data-table mdl-js-data-table">
        <thead>
          <tr class="mdl-color--purple-700">
            <th
              class="mdl-data-table__cell--non-numeric mdl-color-text--white grassetto"
            >
              CALCIATORE
            </th>
            <th
              class="mdl-data-table__cell--non-numeric mdl-color-text--white grassetto"
            >
              SQUADRA
            </th>
            <th class="mdl-color-text--white">GOAL</th>
            <th class="mdl-color-text--white">PRESENZE</th>
            <th class="mdl-color-text--white">RIGORI</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="elemento of marcatori" :key="elemento.id">
            <td class="mdl-data-table__cell--non-numeric">
              {{ elemento.player_name }}
            </td>
            <td class="mdl-data-table__cell--non-numeric">
              {{ elemento.team_name }}
            </td>
            <td>{{ elemento.goals.total }}</td>
            <td>{{ elemento.games.appearences }}</td>
            <td>{{ elemento.penalty.success }}</td>
          </tr>
        </tbody>
      </table>
    </v-app>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "app",
  data() {
    return {
      marcatori: undefined,
    };
  },

  async created() {
    try {
      axios({
        method: "GET",
        url: "https://api-football-v1.p.rapidapi.com/v2/topscorers/2857",
        headers: {
          "content-type": "application/octet-stream",
          "x-rapidapi-host": "api-football-v1.p.rapidapi.com",
          "x-rapidapi-key":
            "ff39fe02a2msh3e312b130495454p1dc972jsn1d36fba9b267",
          useQueryString: true,
        },
      })
        .then((response) => {
          this.marcatori = response.data.api.topscorers;
        })
        .catch((error) => {
          console.log(error);
        });
    } catch (e) {
      console.error(e);
    }
  },
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #6c5ce7;
  margin-top: 60px;
}

.grassetto {
  font-weight: 900 !important;
}
</style>