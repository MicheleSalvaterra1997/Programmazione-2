<template>
  <div id="app">
    <Menu />
  </div>
</template>

<script>
import Menu from "./components/Menu";

export default {
  name: "App",
  components: { Menu },
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #3516be;
  margin-top: 40px;
}
</style>
